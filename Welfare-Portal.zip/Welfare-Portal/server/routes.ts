import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Setup Object Storage
  registerObjectStorageRoutes(app);

  // Helper middleware for admin check
  const requireAdmin = async (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = req.user.claims.sub;
    const user = await storage.getUser(userId);
    if (!user?.isAdmin) {
      return res.status(403).json({ message: "Forbidden: Admins only" });
    }
    next();
  };

  // Services API
  app.get(api.services.list.path, async (req, res) => {
    const services = await storage.getServices();
    res.json(services);
  });

  app.get(api.services.get.path, async (req, res) => {
    const service = await storage.getService(Number(req.params.id));
    if (!service) return res.status(404).json({ message: "Service not found" });
    res.json(service);
  });

  app.post(api.services.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.services.create.input.parse(req.body);
      const service = await storage.createService(input);
      res.status(201).json(service);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors[0].message });
      }
      throw e;
    }
  });

  app.put(api.services.update.path, requireAdmin, async (req, res) => {
    try {
      const input = api.services.update.input.parse(req.body);
      const service = await storage.updateService(Number(req.params.id), input);
      if (!service) return res.status(404).json({ message: "Service not found" });
      res.json(service);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors[0].message });
      }
      throw e;
    }
  });

  app.delete(api.services.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteService(Number(req.params.id));
    res.sendStatus(204);
  });

  // Downloads API
  app.get(api.downloads.list.path, async (req, res) => {
    const downloads = await storage.getDownloads();
    res.json(downloads);
  });

  app.post(api.downloads.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.downloads.create.input.parse(req.body);
      const download = await storage.createDownload(input);
      res.status(201).json(download);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors[0].message });
      }
      throw e;
    }
  });

  app.put(api.downloads.update.path, requireAdmin, async (req, res) => {
    try {
      const input = api.downloads.update.input.parse(req.body);
      const download = await storage.updateDownload(Number(req.params.id), input);
      if (!download) return res.status(404).json({ message: "Download not found" });
      res.json(download);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors[0].message });
      }
      throw e;
    }
  });

  app.delete(api.downloads.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteDownload(Number(req.params.id));
    res.sendStatus(204);
  });

  // Seed Data (if empty)
  app.post("/api/admin/setup", async (req: any, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Login required" });
    const success = await storage.promoteFirstUserToAdmin(req.user.claims.sub);
    if (success) {
      res.json({ message: "You are now an admin! Refresh the page." });
    } else {
      res.status(403).json({ message: "Admin already exists." });
    }
  });

  const existingServices = await storage.getServices();
  if (existingServices.length === 0) {
    await storage.createService({
      title: "Financial Assistance",
      description: "Providing financial aid to those in need.",
      isVisible: true,
      imageUrl: "https://placehold.co/600x400?text=Financial+Aid"
    });
    await storage.createService({
      title: "Medical Support",
      description: "Free medical checkups and medicines for the poor.",
      isVisible: true,
      imageUrl: "https://placehold.co/600x400?text=Medical+Support"
    });
    await storage.createService({
      title: "Education for All",
      description: "Scholarships and free books for deserving students.",
      isVisible: true,
      imageUrl: "https://placehold.co/600x400?text=Education"
    });
  }

  const existingDownloads = await storage.getDownloads();
  if (existingDownloads.length === 0) {
    await storage.createDownload({
      title: "Welfare Application Form",
      fileUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf", // Dummy PDF
      fileType: "pdf",
      isVisible: true
    });
    await storage.createDownload({
      title: "Annual Report 2024",
      fileUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
      fileType: "pdf",
      isVisible: true
    });
  }

  return httpServer;
}
