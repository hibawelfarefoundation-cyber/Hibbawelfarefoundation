## Packages
framer-motion | Smooth page transitions and entry animations
react-hook-form | Efficient form handling
@hookform/resolvers | Zod integration for forms
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility to merge tailwind classes safely

## Notes
- Using Replit Auth for authentication
- Using Object Storage for file uploads
- Admin routes protected by `useAuth` hook
- Images use Unsplash for placeholders if not uploaded
