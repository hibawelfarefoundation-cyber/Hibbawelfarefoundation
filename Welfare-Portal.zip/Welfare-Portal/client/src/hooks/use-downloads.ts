import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

export function useDownloads() {
  return useQuery({
    queryKey: [api.downloads.list.path],
    queryFn: async () => {
      const res = await fetch(api.downloads.list.path);
      if (!res.ok) throw new Error("Failed to fetch downloads");
      return api.downloads.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateDownload() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: z.infer<typeof api.downloads.create.input>) => {
      const res = await fetch(api.downloads.create.path, {
        method: api.downloads.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create download");
      }
      return api.downloads.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.downloads.list.path] });
      toast({ title: "Success", description: "File added successfully" });
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    },
  });
}

export function useUpdateDownload() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & z.infer<typeof api.downloads.update.input>) => {
      const url = buildUrl(api.downloads.update.path, { id });
      const res = await fetch(url, {
        method: api.downloads.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update download");
      return api.downloads.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.downloads.list.path] });
      toast({ title: "Success", description: "File updated successfully" });
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    },
  });
}

export function useDeleteDownload() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.downloads.delete.path, { id });
      const res = await fetch(url, { 
        method: api.downloads.delete.method,
        credentials: "include"
      });
      if (!res.ok) throw new Error("Failed to delete download");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.downloads.list.path] });
      toast({ title: "Success", description: "File deleted successfully" });
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    },
  });
}
