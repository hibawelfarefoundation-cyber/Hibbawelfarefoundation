import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <div className="bg-primary/5 py-16">
        <div className="container mx-auto px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-display font-bold text-primary mb-4"
          >
            About Us
          </motion.h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Learn about our history, mission, and the team driving our vision forward.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 space-y-20">
        <section className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <span className="text-secondary font-bold uppercase tracking-wider text-sm">Our History</span>
            <h2 className="text-3xl font-display font-bold text-foreground">Dedicated to Service Since 2010</h2>
            <p className="text-muted-foreground leading-relaxed">
              Founded with a vision to eliminate poverty and provide equal opportunities, the Welfare Foundation has grown from a small community initiative to a nationwide organization.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Our journey began with a simple food drive. Today, we operate schools, medical camps, and vocational training centers across the region.
            </p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative h-[400px] rounded-2xl overflow-hidden shadow-2xl"
          >
            {/* Unsplash image: group of volunteers working together */}
            <img 
              src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&q=80" 
              alt="Volunteers" 
              className="w-full h-full object-cover"
            />
          </motion.div>
        </section>

        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl font-display font-bold text-foreground mb-4">Our Board</h2>
            <p className="text-muted-foreground">Meet the leadership team.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-6 rounded-xl shadow-lg border border-border text-center"
              >
                <div className="w-24 h-24 mx-auto bg-muted rounded-full mb-4 overflow-hidden">
                   {/* Placeholder avatar */}
                   <img src={`https://ui-avatars.com/api/?name=Member+${i}&background=0D8ABC&color=fff`} alt="Member" />
                </div>
                <h3 className="font-bold text-lg text-primary">Board Member {i}</h3>
                <p className="text-sm text-secondary font-medium mb-2">Director</p>
                <p className="text-sm text-muted-foreground">
                  Dedicated to steering the foundation towards sustainable growth and impact.
                </p>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
