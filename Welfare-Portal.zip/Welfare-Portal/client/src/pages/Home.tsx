import { Navbar } from "@/components/Navbar";
import { useServices } from "@/hooks/use-services";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ServiceCard } from "@/components/ServiceCard";
import { ArrowRight, Heart, Users, Globe } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: services, isLoading } = useServices();

  const visibleServices = services?.filter(s => s.isVisible).slice(0, 3) || [];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-blue-900 text-white">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10 mix-blend-overlay"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-6xl font-display font-bold mb-6 leading-tight"
            >
              Empowering Communities,<br/>
              <span className="text-accent">Restoring Hope</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-blue-100 mb-8 max-w-2xl leading-relaxed"
            >
              We are dedicated to providing essential services, education, and support to underprivileged communities. Join us in making a difference today.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Link href="/contact">
                <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold text-lg px-8 rounded-full shadow-lg shadow-accent/20">
                  Donate Now
                </Button>
              </Link>
              <Link href="/about">
                <Button size="lg" variant="outline" className="text-white border-white/30 hover:bg-white/10 rounded-full">
                  Our Mission
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white -mt-8 relative z-20 container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 shadow-xl rounded-2xl bg-white p-8 border border-border/50">
          <div className="flex items-center gap-4 p-4">
            <div className="p-3 rounded-full bg-blue-50 text-primary">
              <Heart className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-3xl font-bold font-display text-foreground">50k+</h3>
              <p className="text-muted-foreground">Lives Impacted</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 border-l-0 md:border-l border-border/50">
            <div className="p-3 rounded-full bg-blue-50 text-secondary">
              <Users className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-3xl font-bold font-display text-foreground">120+</h3>
              <p className="text-muted-foreground">Volunteers</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 border-l-0 md:border-l border-border/50">
            <div className="p-3 rounded-full bg-blue-50 text-accent">
              <Globe className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-3xl font-bold font-display text-foreground">15+</h3>
              <p className="text-muted-foreground">Cities Reached</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="text-secondary font-bold tracking-wider text-sm uppercase">What We Do</span>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-primary mt-2">Our Services</h2>
            </div>
            <Link href="/services">
              <Button variant="link" className="text-primary hidden sm:flex">
                View All Services <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-96 bg-muted animate-pulse rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {visibleServices.map((service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
          )}
          
          <div className="mt-8 text-center sm:hidden">
             <Link href="/services">
              <Button className="w-full">View All Services</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground relative overflow-hidden">
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/20 rounded-full blur-3xl translate-y-1/3 -translate-x-1/3"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl md:text-5xl font-display font-bold mb-6">Ready to make a difference?</h2>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-10">
            Your support enables us to continue our mission. Whether you donate or volunteer, you are helping build a better future.
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-bold rounded-full">
                Get Involved
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
