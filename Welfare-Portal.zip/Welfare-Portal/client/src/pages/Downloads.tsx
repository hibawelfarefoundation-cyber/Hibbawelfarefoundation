import { Navbar } from "@/components/Navbar";
import { useDownloads } from "@/hooks/use-downloads";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileText, Download as DownloadIcon, FileIcon, ImageIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function Downloads() {
  const { data: downloads, isLoading } = useDownloads();
  const visibleDownloads = downloads?.filter(d => d.isVisible) || [];

  const getIcon = (type: string) => {
    if (type.includes('pdf')) return <FileText className="w-6 h-6 text-red-500" />;
    if (type.includes('image')) return <ImageIcon className="w-6 h-6 text-blue-500" />;
    return <FileIcon className="w-6 h-6 text-gray-500" />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <div className="bg-primary/5 py-16">
        <div className="container mx-auto px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-display font-bold text-primary mb-4"
          >
            Downloads
          </motion.h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
             Access important documents, forms, and reports.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        {isLoading ? (
           <div className="space-y-4">
             {[1, 2, 3].map(i => <div key={i} className="h-20 bg-muted animate-pulse rounded-xl" />)}
           </div>
        ) : (
          <div className="space-y-4">
            {visibleDownloads.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card className="p-4 flex items-center justify-between hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-muted rounded-lg">
                      {getIcon(item.fileType)}
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{item.title}</h3>
                      <p className="text-xs text-muted-foreground uppercase">{item.fileType}</p>
                    </div>
                  </div>
                  <a href={item.fileUrl} target="_blank" rel="noreferrer" download>
                    <Button variant="outline" className="gap-2">
                      <DownloadIcon className="w-4 h-4" />
                      Download
                    </Button>
                  </a>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
        
        {!isLoading && visibleDownloads.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            <p>No downloads available.</p>
          </div>
        )}
      </div>
    </div>
  );
}
