import { Navbar } from "@/components/Navbar";
import { useServices } from "@/hooks/use-services";
import { ServiceCard } from "@/components/ServiceCard";
import { motion } from "framer-motion";

export default function Services() {
  const { data: services, isLoading } = useServices();
  const visibleServices = services?.filter(s => s.isVisible) || [];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <div className="bg-primary/5 py-16">
        <div className="container mx-auto px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-display font-bold text-primary mb-4"
          >
            Our Services
          </motion.h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
             Comprehensive support systems designed to uplift and empower.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-96 bg-muted animate-pulse rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {visibleServices.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        )}
        
        {!isLoading && visibleServices.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            <p>No services available at the moment.</p>
          </div>
        )}
      </div>
    </div>
  );
}
