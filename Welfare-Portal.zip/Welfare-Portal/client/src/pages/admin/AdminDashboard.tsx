import { useServices } from "@/hooks/use-services";
import { useDownloads } from "@/hooks/use-downloads";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Download } from "lucide-react";

export default function AdminDashboard() {
  const { data: services } = useServices();
  const { data: downloads } = useDownloads();

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-display font-bold text-foreground">Dashboard Overview</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Services</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{services?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Active services offered</p>
          </CardContent>
        </Card>
        
        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Downloads</CardTitle>
            <Download className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{downloads?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Files available for download</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Services</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {services?.slice(0, 5).map(service => (
                <div key={service.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                  <span className="font-medium">{service.title}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${service.isVisible ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                    {service.isVisible ? 'Visible' : 'Hidden'}
                  </span>
                </div>
              ))}
              {(!services || services.length === 0) && <p className="text-muted-foreground text-sm">No services yet.</p>}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Downloads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {downloads?.slice(0, 5).map(download => (
                <div key={download.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                  <span className="font-medium truncate max-w-[200px]">{download.title}</span>
                  <span className="text-xs text-muted-foreground uppercase">{download.fileType}</span>
                </div>
              ))}
               {(!downloads || downloads.length === 0) && <p className="text-muted-foreground text-sm">No downloads yet.</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
