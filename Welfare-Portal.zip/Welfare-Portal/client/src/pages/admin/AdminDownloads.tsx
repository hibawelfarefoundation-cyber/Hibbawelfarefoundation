import { useState } from "react";
import { useDownloads, useCreateDownload, useUpdateDownload, useDeleteDownload } from "@/hooks/use-downloads";
import { Download } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useUpload } from "@/hooks/use-upload";
import { Pencil, Trash2, Plus, UploadCloud, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDownloadSchema } from "@shared/schema";
import { z } from "zod";

type DownloadFormData = z.infer<typeof insertDownloadSchema>;

export default function AdminDownloads() {
  const { data: downloads, isLoading } = useDownloads();
  const deleteDownload = useDeleteDownload();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDownload, setEditingDownload] = useState<Download | null>(null);

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this file?")) {
      deleteDownload.mutate(id);
    }
  };

  const openCreate = () => {
    setEditingDownload(null);
    setIsDialogOpen(true);
  };

  const openEdit = (download: Download) => {
    setEditingDownload(download);
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-display font-bold">Manage Downloads</h1>
        <Button onClick={openCreate} className="gap-2">
          <Plus className="w-4 h-4" /> Add File
        </Button>
      </div>

      <div className="border rounded-lg bg-white shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Visibility</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
               <TableRow><TableCell colSpan={4} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : downloads?.length === 0 ? (
               <TableRow><TableCell colSpan={4} className="text-center py-8">No files found.</TableCell></TableRow>
            ) : (
              downloads?.map((download) => (
                <TableRow key={download.id}>
                  <TableCell className="font-medium">{download.title}</TableCell>
                  <TableCell className="uppercase text-xs">{download.fileType}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${download.isVisible ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                      {download.isVisible ? 'Visible' : 'Hidden'}
                    </span>
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(download)}>
                      <Pencil className="w-4 h-4 text-blue-600" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(download.id)}>
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingDownload ? "Edit Download" : "Add New Download"}</DialogTitle>
          </DialogHeader>
          {isDialogOpen && (
             <DownloadForm 
               download={editingDownload} 
               onSuccess={() => setIsDialogOpen(false)} 
             />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DownloadForm({ download, onSuccess }: { download: Download | null, onSuccess: () => void }) {
  const createDownload = useCreateDownload();
  const updateDownload = useUpdateDownload();
  
  // Using useUpload hook directly for better control over the presigned url flow response
  const { uploadFile, isUploading } = useUpload();

  const form = useForm<DownloadFormData>({
    resolver: zodResolver(insertDownloadSchema),
    defaultValues: download || {
      title: "",
      fileUrl: "",
      fileType: "pdf",
      isVisible: true,
    },
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const response = await uploadFile(file);
      if (response) {
        // Map the response objectPath to the public URL served by the backend
        // Backend route: /objects/:objectPath(*)
        const publicUrl = response.objectPath; 
        form.setValue("fileUrl", publicUrl);
        
        // Auto-detect type
        if (file.type.includes("pdf")) form.setValue("fileType", "pdf");
        else if (file.type.includes("image")) form.setValue("fileType", "image");
        else if (file.type.includes("word")) form.setValue("fileType", "docx");
        else form.setValue("fileType", "other");
      }
    } catch (error) {
      console.error("Upload failed", error);
    }
  };

  const onSubmit = (data: DownloadFormData) => {
    if (download) {
      updateDownload.mutate({ id: download.id, ...data }, { onSuccess });
    } else {
      createDownload.mutate(data, { onSuccess });
    }
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">Title</label>
        <Input {...form.register("title")} placeholder="File Title" />
        {form.formState.errors.title && <p className="text-red-500 text-xs">{form.formState.errors.title.message}</p>}
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">File Upload</label>
        <div className="flex gap-2">
          <Button type="button" variant="outline" className="w-full relative" disabled={isUploading}>
            {isUploading ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <UploadCloud className="w-4 h-4 mr-2" />
            )}
            {isUploading ? "Uploading..." : "Choose File"}
            <input 
              type="file" 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              onChange={handleFileUpload}
              accept=".pdf,.doc,.docx,.png,.jpg,.jpeg"
            />
          </Button>
        </div>
        {form.watch("fileUrl") && (
          <p className="text-xs text-green-600 truncate">File ready: {form.watch("fileUrl")}</p>
        )}
        <Input type="hidden" {...form.register("fileUrl")} />
        {form.formState.errors.fileUrl && <p className="text-red-500 text-xs">File is required</p>}
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">File Type</label>
        <Input {...form.register("fileType")} placeholder="e.g. pdf, docx" />
      </div>

      <div className="flex items-center space-x-2">
        <Switch 
          checked={form.watch("isVisible")} 
          onCheckedChange={(checked) => form.setValue("isVisible", checked)} 
        />
        <label className="text-sm font-medium">Visible to public</label>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button variant="outline" type="button" onClick={() => onSuccess?.()}>Cancel</Button>
        <Button type="submit" disabled={createDownload.isPending || updateDownload.isPending || isUploading}>
          {createDownload.isPending || updateDownload.isPending ? "Saving..." : "Save File"}
        </Button>
      </div>
    </form>
  );
}
